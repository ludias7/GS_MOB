import React from "react";
import { Link } from "react-router-dom";

const Register = () => {
  return (
    <div className="register-page">
      <h2>Register</h2>
      <form>
        <label>Name:</label>
        <input type="text" placeholder="Enter your name" />
        <label>Email:</label>
        <input type="email" placeholder="Enter your email" />
        <label>Password:</label>
        <input type="password" placeholder="Enter your password" />
        <label>Confirm Password:</label>
        <input type="password" placeholder="Confirm your password" />
        <button type="submit">Register</button>
      </form>
      <p>
        Already have an account? <Link to="/">Login here</Link>
      </p>
    </div>
  );
};

export default Register;

import React from "react";

const Dashboard = () => {
  return (
    <div className="dashboard-page">
      <h1>Welcome to VoltOn Dashboard</h1>
      <div>
        <h3>Current Charge Status</h3>
        <p>Battery: 80%</p>
        <p>Status: Charging</p>
      </div>
      <div>
        <h3>Energy Preferences</h3>
        <button>Prioritize Renewable Sources</button>
        <button>Set Charging Schedule</button>
      </div>
    </div>
  );
};

export default Dashboard;
